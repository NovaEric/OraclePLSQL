insert into emp values
          (101,'Cano','Presidente',null,'3-FEB-96',450000,null,100);




 insert into emp values
           (102,'Roncal','Director',101,'3-FEB-96',350000,null,100);


 insert into emp values
        (103,'Rueda','Secretario',102,'17-MAR-96',175000,null,100);


 insert into emp values
         (104,'Martin','Contable',102,'17-MAR-96',235000,null,100);

insert into emp values
        (105,'Sanz','Comercial',101,'17-MAR-96',150000,10,100);



 insert into emp values
           (106,'Lopez','Comercial',101,'21-MAR-96',150000,15,100);


 insert into emp values
          (201,'Perez','Director',101,'4-JUN-96',350000,null,200);



 insert into emp values
          (202,'Sastre','Analista',201,'8-JUN-96',300000,null,200);


 insert into emp values
           (203,'Garcia','Programador',202,'8-JUN-96',225000,null,200);



 insert into emp values
           (204,'Mateo','Programador',202,'8-JUN-96',200000,null,200);



 insert into emp values
           (301,'Yuste','Director',101,'3-OCT-96',350000,null,300);


 insert into emp values
           (302,'Recio','Analista',301,'4-FEB-97',300000,null,300);


 insert into emp values
          (303,'Garcia','Programador',302,'4-FEB-97',210000,null,300);


 insert into emp values
         (304,'Santana','Programador',302,'4-FEB-97',200000,null,300);
