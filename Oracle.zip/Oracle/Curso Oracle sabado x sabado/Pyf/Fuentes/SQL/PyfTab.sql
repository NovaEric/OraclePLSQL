-- ============================================================
--   Database name  :  PYF - Pedidos y Facturaci�n
--   DBMS name      :  ORACLE Version 7.0                      
--   Created on     :  2/24/98  2:59 PM                        
-- ============================================================

drop table PYF_TRANSACCIONES cascade constraints;

drop table PYF_DETALLES_TRANSACCIONES cascade constraints;

drop table PYF_TIPOS_PEDIDOS cascade constraints;

drop table PYF_TIPOS_PEDIDOS_CUENTAS cascade constraints;

drop index PYF_DETALLES_PEDIDOS_PK;

drop index PYF_DETALLES_PEDIDOS_FK1;

drop index PYF_DETALLES_PEDIDOS_FK2;

drop table PYF_DETALLES_PEDIDOS cascade constraints;

drop index PYF_DETALLES_MOVIMIENTOS_PK;

drop table PYF_DETALLES_MOVIMIENTOS cascade constraints;

drop table PYF_IMPUESTO_DET_MOVIMIENTO cascade constraints;

drop index PYF_MOVIMIENTOS_DIARIOS_PK;

drop index PYF_MOVIMIENTOS_DIARIOS_FK1;

drop index PYF_MOVIMIENTOS_DIARIOS_FK2;

drop index PYF_MOVIMIENTOS_DIARIOS_FK3;

drop index PYF_MOVIMIENTOS_DIARIOS_FK4;

drop index PYF_MOVIMIENTOS_DIARIOS_FK5;

drop index PYF_MOVIMIENTOS_DIARIOS_FK6;

drop index PYF_MOVIMIENTOS_DIARIOS_FK7;

drop index PYF_MOVIMIENTOS_DIARIOS_FK8;

drop table PYF_MOVIMIENTOS_DIARIOS cascade constraints;

drop index PYF_ALMACENES_USUARIOS_PK;

drop table PYF_ALMACENES_USUARIOS cascade constraints;

drop index PYF_TIPOS_MOVIMIENTOS_PK;

drop index PYF_TIPOS_MOVIMIENTOS_FK1;

drop index PYF_TIPOS_MOVIMIENTOS_FK2;

drop table PYF_TIPOS_MOVIMIENTOS cascade constraints;

drop index PYF_PEDIDOS_CLIENTES_PK;

drop index PYF_PEDIDOS_CLIENTES_FK1;

drop index PYF_PEDIDOS_CLIENTES_FK2;

drop index PYF_PEDIDOS_CLIENTES_FK3;

drop index PYF_PEDIDOS_CLIENTES_FK4;

drop index PYF_PEDIDOS_CLIENTES_FK5;

drop index PYF_PEDIDOS_CLIENTES_FK6;

drop index PYF_PEDIDOS_CLIENTES_FK8;

drop table PYF_PEDIDOS_CLIENTES cascade constraints;

-- ============================================================
--   Table : PYF_PEDIDOS_CLIENTES                              
-- ============================================================
create table PYF_PEDIDOS_CLIENTES
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_DIVISION                     NUMBER                 not null,
    FECHA_CREACION                  DATE                   not null,
    ID_PEDIDO                       NUMBER                 not null,
    ID_PRODUCTO                     NUMBER                 not null,
    ID_TIPO_PEDIDO                  NUMBER                         ,
    ID_CLIENTE                      NUMBER                         ,
    ID_CUENTA_CLIENTE               NUMBER                         ,
    ID_DIRECCION                    NUMBER                         ,
    ID_FORMA_PAGO                   NUMBER                         ,
    ID_OFICINA_VENTA                NUMBER                         ,
    ID_CANAL_VENTA                  NUMBER                         ,
    ID_ALMACEN                      NUMBER                         ,
    ID_ZONA                         NUMBER                         ,
    ID_CONDICION_CREDITO            NUMBER                         ,
    ID_VENDEDOR            	    NUMBER                 not null,
    USUARIO_CREO                    VARCHAR2(10)                   ,
    CONCEPTO                        VARCHAR2(256)                  ,
    ESTATUS_PEDIDO                  CHAR                           ,
    constraint pk_pyf_pedidos_clientes primary key (ID_COMPANIA, ID_DIVISION, FECHA_CREACION, ID_PEDIDO)
	Using Index TableSpace VYMIDX
)
PctFree 20
PctUsed 60
Storage
(
  Initial 24K
  Next 24k
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_TIPOS_MOVIMIENTOS                             
-- ============================================================
create table PYF_TIPOS_MOVIMIENTOS
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_TIPO_MOVIMIENTO              NUMBER                 not null,
    TIPO_MOVIMIENTO_CXC             NUMBER                 	   ,
    TIPO_MOVIMIENTO_EXI             NUMBER                 	   ,
    DESCRIPCION                     VARCHAR2(40)           not null,
    DESCRIPCION_CORTA               VARCHAR2(10)                   ,
    ORIGEN_TRANSACCION              VARCHAR2(1)                    
        constraint ck_pyf_tipo_origen_transaccion check (ORIGEN_TRANSACCION is null or (ORIGEN_TRANSACCION in ('D','C'))),
    ULTIMA_REFERENCIA               NUMBER                         ,
    MOVIMIENTO_NC_CXC               NUMBER                 	   ,
    MOVIMIENTO_ND_CXC               NUMBER                 	   ,
    ESTATUS                         VARCHAR2(1)                    
        constraint ck_pyf_tipo_estatus check (ESTATUS is null or (ESTATUS in ('A','I'))),
    constraint pk_pyf_tipos_movimientos primary key (ID_COMPANIA, ID_TIPO_MOVIMIENTO)
	Using Index TableSpace VYMIDX
)
PctFree 5
PctUsed 90
Storage
(
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_ALMACENES_USUARIOS                            
-- ============================================================
create table PYF_ALMACENES_USUARIOS
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_USUARIO                      VARCHAR2(10)           not null,
    ID_ALMACEN                      NUMBER                 not null,
    constraint pk_pyf_almacenes_usuarios primary key (ID_COMPANIA, ID_USUARIO, ID_ALMACEN)
	Using Index TableSpace VYMIDX
)
PctFree 5
PctUsed 90
Storage
(
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_MOVIMIENTOS_DIARIOS                           
-- ============================================================
create table PYF_MOVIMIENTOS_DIARIOS
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_DIVISION                     NUMBER                 not null,
    ID_TIPO_MOVIMIENTO              NUMBER                 not null,
    ID_REFERENCIA                   NUMBER                 not null,
    FECHA_MOVIMIENTO		    DATE		   not null,
    ID_CLIENTE                      NUMBER                 not null,
    ID_CUENTA_CLIENTE               NUMBER                 not null,
    ID_DIRECCION                    NUMBER                 	   ,
    ID_CONDICION_CREDITO            NUMBER                 	   ,
    ID_FORMA_PAGO                   NUMBER                 	   ,
    ID_OFICINA_VENTA                NUMBER                 	   ,
    ID_ZONA                         NUMBER                 not null,
    ID_CANAL_VENTA                  NUMBER                 not null,
    ID_ALMACEN                      NUMBER                 	   ,
    ID_VENDEDOR			    NUMBER                 	   ,
    ID_PRODUCTO			    NUMBER                 not null,
    MONTO_MOVIMIENTO		    NUMBER(11,2)		   ,
    MONTO_IMPUESTO		    NUMBER(11,2)		   ,
    MONTO_COMISION		    NUMBER(11,2)		   ,
    COMISION_CALCULAR	    	    NUMBER(11,2)		   ,
    CONCEPTO                        VARCHAR2(256)                  ,
    ESTATUS		            VARCHAR2(1)			   ,
    constraint pk_pyf_movimientos_diarios primary key (ID_COMPANIA, ID_DIVISION, ID_TIPO_MOVIMIENTO, ID_REFERENCIA)
	Using Index TableSpace VYMIDX
)
PctFree 5
PctUsed 60
Storage
(
  Initial 12059K
  Next 12059K
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_DETALLES_MOVIMIENTOS                          
-- ============================================================
create table PYF_DETALLES_MOVIMIENTOS
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_TIPO_MOVIMIENTO              NUMBER                 not null,
    ID_REFERENCIA                   NUMBER                 not null,
    ID_SECUENCIA		    NUMBER                 not null,
    ID_PRODUCTO                     NUMBER                 not null,
    ID_SUB_PRODUCTO                 NUMBER                 not null,
    CANTIDAD                        NUMBER(11,2)           not null,
    PRECIO_VENTA                    NUMBER(11,2)           	   ,
    PROMOCION			    VARCHAR2(1)		           ,
    MONTO_IMPUESTO                  NUMBER(11,2)		   ,
    constraint pk_pyf_detalles_movimientos primary key (ID_COMPANIA, ID_TIPO_MOVIMIENTO, ID_REFERENCIA, ID_SECUENCIA)
	Using Index TableSpace VYMIDX
)
PctFree 5
PctUsed 60
Storage
(
  Initial 6248K
  Next 6248K
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_IMPUESTO_DET_MOVIMIENTO                          
-- ============================================================
create table PYF_IMPUESTO_DET_MOVIMIENTO
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_TIPO_MOVIMIENTO              NUMBER                 not null,
    ID_REFERENCIA                   NUMBER                 not null,
    ID_SECUENCIA		    NUMBER                 not null,
    ID_IMPUESTO                     NUMBER                 not null,
    MONTO_IMPUESTO                  NUMBER(11,2)           not null,
     constraint pk_pyf_impuesto_det_movimiento primary key (ID_COMPANIA, ID_TIPO_MOVIMIENTO, ID_REFERENCIA, ID_SECUENCIA, ID_IMPUESTO)
	Using Index TableSpace VYMIDX
)
PctFree 5
PctUsed 60
Storage
(
  Initial 54K
  Next 54k
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_DETALLES_PEDIDOS                              
-- ============================================================
create table PYF_DETALLES_PEDIDOS
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_DIVISION                     NUMBER                 not null,
    FECHA_CREACION                  DATE                   not null,
    ID_PEDIDO                       NUMBER                 not null,
    ID_SECUENCIA		    NUMBER                 not null,
    ID_PRODUCTO                     NUMBER                 not null,
    ID_SUB_PRODUCTO                 NUMBER                 not null,
    CANTIDAD                        NUMBER(11,2)           not null,
    PRECIO_VENTA		    NUMBER(11,2)           	   ,
    PROMOCION			    VARCHAR2(1)			   ,
    constraint pk_pyf_detalles_pedidos primary key (ID_COMPANIA, ID_DIVISION, FECHA_CREACION, ID_PEDIDO, ID_SECUENCIA)
	Using Index TableSpace VYMIDX
)
PctFree 20
PctUsed 60
Storage
(
  Initial 42K
  Next 42K
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_TIPOS_PEDIDOS                                 
-- ============================================================
create table PYF_TIPOS_PEDIDOS
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_TIPO_PEDIDO                  NUMBER                 not null,
    DESCRIPCION                     VARCHAR2(40)           not null,
    DESCRIPCION_CORTA               VARCHAR2(10)                   ,
    TIPO_VENTA		      	    CHAR(1)			   ,
    ID_TIPO_MOVIMIENTO              NUMBER                 not null,
    constraint pk_pyf_tipos_pedidos primary key (ID_COMPANIA, ID_TIPO_PEDIDO)
	Using Index TableSpace VYMIDX
)
PctFree 5
PctUsed 90
Storage
(
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_TIPOS_PEDIDOS_CUENTAS
-- ============================================================
create table PYF_TIPOS_PEDIDOS_CUENTAS
(
    ID_COMPANIA                     NUMBER                 not null,
    ID_TIPO_PEDIDO                  NUMBER                 not null,
    ID_LINEAS                       NUMBER                 not null,
    ID_CALCULO                      NUMBER                 	   ,
    ID_CUENTA_CONTABLE              NUMBER                 not null,
    ORIGEN_TRANSACCION              VARCHAR2(1)            not null
        constraint ck_cxc_tipo_origen_transaccion check (ORIGEN_TRANSACCION in ('D','C')),
    SUMARIZADA                      VARCHAR2(1)            not null
        constraint ck_cxc_tipo_sumarizada check (SUMARIZADA in ('S','N')),
    ID_MOVIMIENTO_CONCILIACION      VARCHAR2(2)			    ,
    constraint pk_pyf_tipos_pedidos_cuent primary key (ID_COMPANIA, ID_TIPO_PEDIDO, ID_LINEAS)
	Using Index TableSpace VYMIDX
)
PctFree 5
PctUsed 90
Storage
(
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_TRANSACCIONES
-- ============================================================
create table PYF_TRANSACCIONES
(
    ID_COMPANIA             NUMBER                 	not null,
    ID_DIVISION             NUMBER                 	not null,
    FECHA_CREACION 	    DATE			not null,
    ID_CLIENTE		    NUMBER                 	not null,
    ID_CUENTA_CLIENTE       NUMBER                 	not null,
    ID_TIPO_MOVIMIENTO	    NUMBER                 	not null,
    ID_PRODUCTO		    NUMBER                	not null,
    ID_DOCUMENTO	    NUMBER                		,
    ID_VENDEDOR		    NUMBER                 		,
    ID_DIRECCION	    NUMBER                  		,
    ID_CONDICION_CREDITO    NUMBER                 	     	,
    ID_FORMA_PAGO           NUMBER                 		,
    ID_ALMACEN		    NUMBER			   	,
    MONTO_TRANSACCION	    NUMBER(11,2)			,
    MONTO_COMISION	    NUMBER(11,2)			,
    MONTO_IMPUESTO	    NUMBER(11,2)			,
    CONCEPTO		    VARCHAR2(256)			,
    USUARIO_CREO	    VARCHAR2(10)		not null,
    constraint pk_pyf_transacciones primary key (ID_COMPANIA,
			              		 ID_DIVISION,
					     	 FECHA_CREACION,
				      		 ID_CLIENTE,
				      		 ID_CUENTA_CLIENTE,
						 ID_TIPO_MOVIMIENTO)
	Using Index TableSpace VYMIDX
)
PctFree 20
PctUsed 60
Storage
(
  Initial 95K
  Next 95K
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   Table : PYF_DETALLES_TRANSACCIONES
-- ============================================================
create table PYF_DETALLES_TRANSACCIONES
(
    ID_COMPANIA             	NUMBER                 not null,
    ID_DIVISION             	NUMBER                 not null,
    FECHA_CREACION 	    	DATE		       not null,
    ID_CLIENTE		    	NUMBER                 not null,
    ID_CUENTA_CLIENTE       	NUMBER                 not null,
    ID_TIPO_MOVIMIENTO	    	NUMBER                 not null,
    ID_SECUENCIA		NUMBER                 not null,
    ID_PRODUCTO		    	NUMBER                 not null,
    ID_SUB_PRODUCTO	    	NUMBER                 not null,
    CANTIDAD		    	NUMBER(11,2)		       ,
    PRECIO_VENTA            	NUMBER(11,2)		       ,
    PROMOCION		    	VARCHAR2(1)		       ,
    constraint pk_pyf_detalles_transacci primary key (ID_COMPANIA,
					              ID_DIVISION,
						      FECHA_CREACION,
						      ID_CLIENTE,
						      ID_CUENTA_CLIENTE,
						      ID_TIPO_MOVIMIENTO,
						      ID_SECUENCIA)
	Using Index TableSpace VYMIDX
)
PctFree 20
PctUsed 60
Storage
(
  Initial 72K
  Next 72K
  PctIncrease 0
)
TableSpace VYMDAT;

-- ============================================================
--   View : PYF_PEDIDOS_CLIENTES_V1   
-- ============================================================
Create or Replace View Pyf_Pedidos_Clientes_V1 as
 Select D.Id_Compania,
        D.Id_Division,
        D.Fecha_Creacion,
	D.Id_Pedido,
	D.Id_Cliente,
        G.Descripcion Desc_Cliente,
	D.Id_Almacen,
	H.Descripcion Desc_Almacen,
	D.Id_Oficina_Venta,
	I.Descripcion Desc_Oficina_Venta,
	D.Estatus_Pedido,
	D.Usuario_Creo,
	B.Usuario_Supervisor,
	C.Id_Usuario,
	C.Usuario_Supervisado
   From Gen_Companias A,
	Gen_Usuarios B,
	Vym_Oficinas_Ventas I,
	Gen_Usuarios_Supervisores C,
	Exi_Almacenes H,
	Pyf_Pedidos_Clientes D,
        Gen_Entidades_Generales E,
        Gen_Entidades_Generales F,
        Gen_Entidades_Generales G
     Where A.Id_Compania = D.Id_Compania
       And D.Id_Compania = E.Id_Entidad
       And D.Id_Division = F.Id_Entidad
       And B.Id_Usuario = C.Id_Usuario(+)
       And (D.Usuario_Creo in (C.Id_Usuario, C.Usuario_Supervisado))
       And D.Id_Cliente = G.Id_Entidad
       And (D.Id_Compania = H.Id_Compania And
	    D.Id_Almacen = H.Id_Almacen)
       And (D.Id_Compania = I.Id_Compania And
	    D.Id_Oficina_Venta= I.Id_Oficina_Venta)
    with check option;

-- ============================================================
--   View : PYF_TRANSACCIONES_V1   
-- ============================================================
Create or Replace View Pyf_Transacciones_V1 as
 Select D.Id_Compania,
        D.Id_Division,
	D.Fecha_Creacion,
	D.Id_Cliente,
        G.Descripcion Desc_Cliente,
	D.Id_Cuenta_Cliente,
	H.Descripcion Desc_Cuenta_Cliente,
	D.Id_Tipo_Movimiento,
	I.Descripcion Desc_Tipo_Movimiento,
	D.Usuario_Creo,
	C.Id_Usuario Usuario_Supervisor
   From Gen_Companias A,
	Gen_Usuarios B,
	Gen_Usuarios_Supervisores C,
 	Pyf_Transacciones D,
        Gen_Entidades_Generales E,
        Gen_Entidades_Generales F,
        Gen_Entidades_Generales G,
	Cxc_Cuentas_Clientes H,
	Pyf_Tipos_Movimientos I
     Where A.Id_Compania = D.Id_Compania
       And D.Id_Compania = E.Id_Entidad
       And D.Id_Division = F.Id_Entidad
       And B.Id_Usuario = C.Id_Usuario
       And (D.Usuario_Creo in (C.Id_Usuario, C.Usuario_Supervisado))
       And D.Id_Cliente = G.Id_Entidad
       And (D.Id_Cliente = H.Id_Cliente And
	    D.Id_Cuenta_Cliente = H.Id_Cuenta_Cliente)
       And (D.Id_Compania = I.Id_Compania And
            D.Id_Tipo_Movimiento = I.Id_Tipo_Movimiento)
   with check option;

-- ============================================================
--   View : PYF_MOVIMIENTOS_DIARIOS_V1   
-- ============================================================
Create or Replace View Pyf_Movimientos_Diarios_V1 as
Select F.Id_Compania,
       F.Id_Division,
       F.Id_Tipo_Movimiento,
       B.Descripcion Desc_Tipo_Movimiento,
       F.Id_Referencia,
       F.Id_Cliente,
       C.Descripcion Desc_Cliente,
       F.Id_Cuenta_Cliente,
       E.Descripcion Desc_Cuenta_Cliente,
       F.Fecha_Movimiento,
       F.Id_Vendedor,
       D.Descripcion Desc_Vendedor,
       F.Id_Producto,
       B.Descripcion Desc_Producto,
       F.Monto_Movimiento
  From Pyf_Tipos_Movimientos A,
       Vym_Productos B,
       Gen_Entidades_Generales C,
       Gen_Entidades_Generales D,
       Cxc_Cuentas_Clientes E,
       Pyf_Movimientos_Diarios F
   Where F.Id_Tipo_Movimiento = A.Id_Tipo_Movimiento
     And F.Id_Producto = B.Id_Producto
     And F.Id_Cliente = C.Id_Entidad
     And F.Id_Vendedor = D.Id_Entidad
     And (F.Id_Cliente = E.Id_Cliente And
	  F.Id_Cuenta_Cliente = E.Id_Cuenta_Cliente)
   with check option;

-- ============================================================
--   Creaci�n de los indices de las tablas
-- ============================================================
--   Index : PYF_PEDIDOS_CLIENTES_FK1                          
-- ============================================================
create index PYF_PEDIDOS_CLIENTES_FK1 on PYF_PEDIDOS_CLIENTES (ID_CLIENTE asc)
PctFree 10
Storage
(
  Initial 21K
  Next 21K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_PEDIDOS_CLIENTES_FK2                          
-- ============================================================
create index PYF_PEDIDOS_CLIENTES_FK2 on PYF_PEDIDOS_CLIENTES (ID_CLIENTE asc, ID_CUENTA_CLIENTE asc)
PctFree 10
Storage
(
  Initial 21K
  Next 21K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_PEDIDOS_CLIENTES_FK3                          
-- ============================================================
create index PYF_PEDIDOS_CLIENTES_FK3 on PYF_PEDIDOS_CLIENTES (ID_FORMA_PAGO asc)
PctFree 10
Storage
(
  Initial 21K
  Next 21K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_PEDIDOS_CLIENTES_FK4                          
-- ============================================================
create index PYF_PEDIDOS_CLIENTES_FK4 on PYF_PEDIDOS_CLIENTES (ID_OFICINA_VENTA asc)
PctFree 10
Storage
(
  Initial 21K
  Next 21K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_PEDIDOS_CLIENTES_FK5                          
-- ============================================================
create index PYF_PEDIDOS_CLIENTES_FK5 on PYF_PEDIDOS_CLIENTES (ID_CANAL_VENTA asc)
PctFree 10
Storage
(
  Initial 21K
  Next 21K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_PEDIDOS_CLIENTES_FK6                          
-- ============================================================
create index PYF_PEDIDOS_CLIENTES_FK6 on PYF_PEDIDOS_CLIENTES (ID_ZONA asc)
PctFree 10
Storage
(
  Initial 21K
  Next 21K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_PEDIDOS_CLIENTES_FK8                          
-- ============================================================
create index PYF_PEDIDOS_CLIENTES_FK8 on PYF_PEDIDOS_CLIENTES (ID_VENDEDOR asc)
PctFree 10
Storage
(
  Initial 21K
  Next 21K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_TIPOS_MOVIMIENTOS_FK1                         
-- ============================================================
create index PYF_TIPOS_MOVIMIENTOS_FK1 on PYF_TIPOS_MOVIMIENTOS (TIPO_MOVIMIENTO_CXC asc)
PctFree 10
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_TIPOS_MOVIMIENTOS_FK2                         
-- ============================================================
create index PYF_TIPOS_MOVIMIENTOS_FK2 on PYF_TIPOS_MOVIMIENTOS (TIPO_MOVIMIENTO_EXI asc)
PctFree 10
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK1                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK1 on PYF_MOVIMIENTOS_DIARIOS (ID_CLIENTE asc, ID_CUENTA_CLIENTE asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK2                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK2 on PYF_MOVIMIENTOS_DIARIOS (ID_DIRECCION asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK3                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK3 on PYF_MOVIMIENTOS_DIARIOS (ID_CONDICION_CREDITO asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK4                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK4 on PYF_MOVIMIENTOS_DIARIOS (ID_FORMA_PAGO asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK5                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK5 on PYF_MOVIMIENTOS_DIARIOS (ID_OFICINA_VENTA asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK6                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK6 on PYF_MOVIMIENTOS_DIARIOS (ID_ZONA asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK7                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK7 on PYF_MOVIMIENTOS_DIARIOS (ID_CANAL_VENTA asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   Index : PYF_MOVIMIENTOS_DIARIOS_FK8                       
-- ============================================================
create index PYF_MOVIMIENTOS_DIARIOS_FK8 on PYF_MOVIMIENTOS_DIARIOS (ID_ALMACEN asc)
PctFree 10
Storage
(
  Initial 10299K
  Next 10299K
)
TableSpace VYMIDX;

-- ============================================================
--   View : PYF_TRANSACCIONES_V1   
-- ============================================================
Create or Replace View Pyf_Transacciones_V1 as
 Select D.Id_Compania,
        D.Id_Division,
	D.Fecha_Creacion,
	D.Id_Cliente,
        G.Descripcion Desc_Cliente,
	D.Id_Cuenta_Cliente,
	H.Descripcion Desc_Cuenta_Cliente,
	D.Id_Tipo_Movimiento,
	I.Descripcion Desc_Tipo_Movimiento,
	D.Usuario_Creo,
	C.Id_Usuario Usuario_Supervisor
   From Gen_Companias A,
	Gen_Usuarios B,
	Gen_Usuarios_Supervisores C,
 	Pyf_Transacciones D,
        Gen_Entidades_Generales E,
        Gen_Entidades_Generales F,
        Gen_Entidades_Generales G,
	Cxc_Cuentas_Clientes H,
	Pyf_Tipos_Movimientos I
     Where A.Id_Compania = D.Id_Compania
       And D.Id_Compania = E.Id_Entidad
       And D.Id_Division = F.Id_Entidad
       And B.Id_Usuario = C.Id_Usuario
       And (D.Usuario_Creo in (C.Id_Usuario, C.Usuario_Supervisado))
       And D.Id_Cliente = G.Id_Entidad
       And (D.Id_Cliente = H.Id_Cliente And
	    D.Id_Cuenta_Cliente = H.Id_Cuenta_Cliente)
       And (D.Id_Compania = I.Id_Compania And
            D.Id_Tipo_Movimiento = I.Id_Tipo_Movimiento)
   with check option;

-- ============================================================
--   View : PYF_MOVIMIENTOS_DIARIOS_V1   
-- ============================================================
Create or Replace View Pyf_Movimientos_Diarios_V1 as
Select F.Id_Compania,
       F.Id_Division,
       F.Id_Tipo_Movimiento,
       B.Descripcion Desc_Tipo_Movimiento,
       F.Id_Referencia,
       F.Id_Cliente,
       C.Descripcion Desc_Cliente,
       F.Id_Cuenta_Cliente,
       E.Descripcion Desc_Cuenta_Cliente,
       F.Fecha_Movimiento,
       F.Id_Vendedor,
       D.Descripcion Desc_Vendedor,
       F.Id_Producto,
       B.Descripcion Desc_Producto,
       F.Monto_Movimiento
  From Pyf_Tipos_Movimientos A,
       Vym_Productos B,
       Gen_Entidades_Generales C,
       Gen_Entidades_Generales D,
       Cxc_Cuentas_Clientes E,
       Pyf_Movimientos_Diarios F
   Where F.Id_Tipo_Movimiento = A.Id_Tipo_Movimiento
     And F.Id_Producto = B.Id_Producto
     And F.Id_Cliente = C.Id_Entidad
     And F.Id_Vendedor = D.Id_Entidad
     And (F.Id_Cliente = E.Id_Cliente And
	  F.Id_Cuenta_Cliente = E.Id_Cuenta_Cliente)
   with check option;

-- ============================================================
--   Referencias entre las tablas
-- ============================================================

alter table PYF_TIPOS_MOVIMIENTOS
    add constraint fk1_pyf_tipos_movimientos foreign key (ID_COMPANIA)
       references GEN_COMPANIAS (ID_COMPANIA);

alter table PYF_TIPOS_MOVIMIENTOS
    add constraint fk2_pyf_tipos_movimientos foreign key (ID_COMPANIA, TIPO_MOVIMIENTO_CXC)
       references CXC_TIPOS_MOVIMIENTOS (ID_COMPANIA, ID_TIPO_MOVIMIENTO);

alter table PYF_TIPOS_MOVIMIENTOS
    add constraint fk3_pyf_tipos_movimientos foreign key (ID_COMPANIA, TIPO_MOVIMIENTO_EXI)
       references EXI_TIPOS_MOVIMIENTOS (ID_COMPANIA, ID_TIPO_MOVIMIENTO);

alter table PYF_ALMACENES_USUARIOS
    add constraint fk1_pyf_almacenes_usuarios foreign key (ID_COMPANIA, ID_ALMACEN)
       references EXI_ALMACENES (ID_COMPANIA, ID_ALMACEN);

alter table PYF_ALMACENES_USUARIOS
    add constraint fk2_pyf_almacenes_usuarios foreign key (ID_USUARIO)
       references GEN_USUARIOS (ID_USUARIO);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk1_pyf_movimientos_diarios foreign key (ID_COMPANIA, ID_CLIENTE, ID_CUENTA_CLIENTE)
       references CXC_CUENTAS_CLIENTES (ID_COMPANIA, ID_CLIENTE, ID_CUENTA_CLIENTE);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk2_pyf_movimientos_diarios foreign key (ID_COMPANIA, ID_CLIENTE, ID_DIRECCION)
       references VYM_DIRECCIONES_CLIENTES (ID_COMPANIA, ID_CLIENTE, ID_DIRECCION);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk3_pyf_movimientos_diarios foreign key (ID_CONDICION_CREDITO)
       references CXC_CONDICIONES_CREDITOS (ID_CONDICION_CREDITO);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk4_pyf_movimientos_diarios foreign key (ID_FORMA_PAGO)
       references CXC_FORMAS_PAGOS (ID_FORMA_PAGO);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk5_pyf_movimientos_diarios foreign key (ID_COMPANIA, ID_OFICINA_VENTA)
       references VYM_OFICINAS_VENTAS (ID_COMPANIA, ID_OFICINA_VENTA);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk6_pyf_movimientos_diarios foreign key (ID_COMPANIA, ID_ZONA)
       references VYM_ZONAS (ID_COMPANIA, ID_ZONA);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk7_pyf_movimientos_diarios foreign key (ID_COMPANIA, ID_CANAL_VENTA)
       references VYM_CANALES_VENTAS (ID_COMPANIA, ID_CANAL_VENTA);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk8_pyf_movimientos_diarios foreign key (ID_COMPANIA, ID_ALMACEN)
       references EXI_ALMACENES (ID_COMPANIA, ID_ALMACEN);

alter table PYF_MOVIMIENTOS_DIARIOS
    add constraint fk9_pyf_movimientos_diarios foreign key (ID_COMPANIA, ID_TIPO_MOVIMIENTO)
       references PYF_TIPOS_MOVIMIENTOS (ID_COMPANIA, ID_TIPO_MOVIMIENTO);

alter table PYF_DETALLES_MOVIMIENTOS
    add constraint fk1_pyf_detalles_movimientos foreign key (ID_COMPANIA, ID_TIPO_MOVIMIENTO, ID_REFERENCIA)
       references PYF_MOVIMIENTOS_DIARIOS (ID_COMPANIA, ID_TIPO_MOVIMIENTO, ID_REFERENCIA);

alter table PYF_DETALLES_MOVIMIENTOS
    add constraint fk2_pyf_detalles_movimientos foreign key (ID_COMPANIA, ID_PRODUCTO, ID_SUB_PRODUCTO)
       references VYM_SUBPRODUCTOS (ID_COMPANIA, ID_PRODUCTO, ID_SUB_PRODUCTO);

alter table PYF_IMPUESTO_DET_MOVIMIENTO
    add constraint fk1_pyf_Impuesto_det_mov foreign key (ID_COMPANIA, ID_TIPO_MOVIMIENTO, ID_REFERENCIA, ID_SECUENCIA)
       references PYF_DETALLES_MOVIMIENTOS (ID_COMPANIA, ID_TIPO_MOVIMIENTO, ID_REFERENCIA, ID_SECUENCIA);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk1_pyf_pedidos_clientes foreign key (ID_COMPANIA, ID_CLIENTE, ID_CUENTA_CLIENTE)
       references CXC_CUENTAS_CLIENTES (ID_COMPANIA, ID_CLIENTE, ID_CUENTA_CLIENTE);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk2_pyf_pedidos_clientes foreign key (ID_COMPANIA, ID_CLIENTE, ID_DIRECCION)
       references VYM_DIRECCIONES_CLIENTES (ID_COMPANIA, ID_CLIENTE, ID_DIRECCION);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk3_pyf_pedidos_clientes foreign key (ID_FORMA_PAGO)
       references CXC_FORMAS_PAGOS (ID_FORMA_PAGO);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk4_pyf_pedidos_clientes foreign key (ID_COMPANIA, ID_OFICINA_VENTA)
       references VYM_OFICINAS_VENTAS (ID_COMPANIA, ID_OFICINA_VENTA);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk5_pyf_pedidos_clientes foreign key (ID_COMPANIA, ID_CANAL_VENTA)
       references VYM_CANALES_VENTAS (ID_COMPANIA, ID_CANAL_VENTA);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk6_pyf_pedidos_clientes foreign key (ID_CONDICION_CREDITO)
       references CXC_CONDICIONES_CREDITOS (ID_CONDICION_CREDITO);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk7_pyf_pedidos_clientes foreign key (ID_COMPANIA, ID_ALMACEN)
       references EXI_ALMACENES (ID_COMPANIA, ID_ALMACEN);

alter table PYF_PEDIDOS_CLIENTES
    add constraint fk8_pyf_pedidos_clientes foreign key (ID_COMPANIA, ID_VENDEDOR)
       references VYM_VENDEDORES (ID_COMPANIA, ID_VENDEDOR);

alter table PYF_DETALLES_PEDIDOS
    add constraint fk1_pyf_detalles_pedidos foreign key (ID_COMPANIA, ID_DIVISION, FECHA_CREACION, ID_PEDIDO)
       references PYF_PEDIDOS_CLIENTES (ID_COMPANIA, ID_DIVISION, FECHA_CREACION, ID_PEDIDO)
    ON DELETE CASCADE;

alter table PYF_TIPOS_PEDIDOS
    add constraint fk1_pyf_tipos_pedidos foreign key (ID_COMPANIA)
       references GEN_COMPANIAS (ID_COMPANIA);

alter table PYF_TIPOS_PEDIDOS
    add constraint fk2_pyf_tipos_pedidos foreign key (ID_COMPANIA, ID_TIPO_MOVIMIENTO)
       references PYF_TIPOS_MOVIMIENTOS (ID_COMPANIA, ID_TIPO_MOVIMIENTO);

alter table PYF_TIPOS_PEDIDOS_CUENTAS
    add constraint fk1_pyf_tipos_pedidos_cuentas foreign key (ID_COMPANIA, ID_TIPO_PEDIDO)
       references PYF_TIPOS_PEDIDOS (ID_COMPANIA, ID_TIPO_PEDIDO);